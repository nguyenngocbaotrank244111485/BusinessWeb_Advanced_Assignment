const surveyRoutes = require('./routes/survey.routes');

app.use('/api/survey', surveyRoutes);