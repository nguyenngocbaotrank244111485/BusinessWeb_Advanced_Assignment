const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { validateQuestions, validateSubmission } = require('../utils/survey-validation');

const seed = JSON.parse(fs.readFileSync(
  path.resolve(__dirname, '../seeds/surveyQuestions.json'), 'utf8'
));
const validAnswers = seed.map(q => ({ questionId: q._id, score: 4 }));

test('20 questions and 4 TAM groups are configured correctly', () => {
  assert.equal(seed.length, 20);
  assert.equal(validateQuestions(seed), true);
  for (const dimension of ['PU', 'EOU', 'SAT', 'PI']) {
    assert.equal(seed.filter(q => q.dimension === dimension).length, 5);
  }
});
test('valid 20-answer request passes', () => {
  assert.equal(validateSubmission({ answers: validAnswers, comment: 'Tốt' }, seed), null);
});
test('missing answer fails', () => {
  assert.equal(validateSubmission({ answers: validAnswers.slice(1), comment: '' }, seed), 'INVALID_SURVEY_DATA');
});
test('duplicate question ID fails', () => {
  const bad = [...validAnswers];
  bad[1] = { ...bad[0] };
  assert.equal(validateSubmission({ answers: bad, comment: '' }, seed), 'INVALID_ANSWER');
});
test('out-of-range/string/noninteger scores fail', () => {
  for (const score of [0, 6, '5', 3.5]) {
    const bad = validAnswers.map((a, i) => i === 0 ? { ...a, score } : a);
    assert.equal(validateSubmission({ answers: bad, comment: '' }, seed), 'INVALID_ANSWER');
  }
});
test('comment max 500 characters', () => {
  assert.equal(validateSubmission({ answers: validAnswers, comment: 'a'.repeat(501) }, seed), 'INVALID_SURVEY_DATA');
});

const VALID_DIMENSIONS = new Set(['PU', 'EOU', 'SAT', 'PI']);

function validateQuestions(questions) {
  if (!Array.isArray(questions) || questions.length === 0) return false;
  const ids = new Set();
  const orderIndexes = new Set();
  for (const q of questions) {
    if (!q || typeof q._id !== 'string' || !q._id || ids.has(q._id) ||
        !VALID_DIMENSIONS.has(q.dimension) ||
        q.scaleType !== 'LIKERT_5' ||
        !Number.isInteger(q.orderIndex) || orderIndexes.has(q.orderIndex) ||
        typeof q.text !== 'string' || !q.text.trim() ||
        q.isActive !== true) {
      return false;
    }
    ids.add(q._id);
    orderIndexes.add(q.orderIndex);
  }
  return true;
}

/** Return null if valid, or a stable 422 validation code. */
function validateSubmission(body, questions) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return 'INVALID_SURVEY_DATA';
  }
  const { answers, comment = '' } = body;
  if (!Array.isArray(answers) || answers.length !== questions.length ||
      typeof comment !== 'string' || comment.length > 500) {
    return 'INVALID_SURVEY_DATA';
  }
  const expectedIds = new Set(questions.map(q => q._id));
  const seen = new Set();
  for (const item of answers) {
    if (!item || typeof item !== 'object' ||
        typeof item.questionId !== 'string' ||
        !expectedIds.has(item.questionId) || seen.has(item.questionId) ||
        !Number.isInteger(item.score) || item.score < 1 || item.score > 5) {
      return 'INVALID_ANSWER';
    }
    seen.add(item.questionId);
  }
  return null;
}

module.exports = { validateQuestions, validateSubmission };