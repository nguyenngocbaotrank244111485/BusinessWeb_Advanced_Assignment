import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PrintifyHomepage } from './printify-homepage/printify-homepage';
import { SurveyQuestionsComponent } from './survey-questions-component/survey-questions-component';

const routes: Routes = [
  {path: '', component: PrintifyHomepage, pathMatch: 'full'},
  {path: 'printify-homepage',component: PrintifyHomepage},
  {path: 'survey-questions-component',component: SurveyQuestionsComponent},
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
